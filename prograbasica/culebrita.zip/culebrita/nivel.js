class Nivel {
  constructor() {
      this.nivel = 1;
      this.terminado = false;
      this.maxComida = 0;
  }
}
