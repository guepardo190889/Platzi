var TECLAS = {
  UP: 38,
  DOWN: 40,
  LEFT: 37,
  RIGTH: 39
};
